import Navbar from "../../components/common/Navbar";
import MenuBar from "../../components/common/MenuBar";
import Hero from "../../components/Hero/Hero";
import Categories from "../../components/Categories/Categories";
import FeaturedProducts from "../../components/Product/FeaturedProducts";
import Footer from "../../components/common/Footer";


function Home() {
  return (
    <div className="min-h-screen bg-[#f8f9fc]">

      <Navbar />

      <MenuBar />

      <main className="max-w-[1500px] mx-auto px-6">

        <Hero />

        <Categories />

        <FeaturedProducts />

      </main>

      <Footer />

    </div>
  );
}

export default Home;