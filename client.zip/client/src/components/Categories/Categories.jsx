import {
  FiBook,
  FiMonitor,
  FiSmartphone,
  FiHome,
  FiActivity,
  FiGrid,
} from "react-icons/fi";

import CategoryCard from "./CategoryCard";

const categories = [
  {
    title: "Books",
    count: 145,
    icon: FiBook,
    color: "bg-purple-100 text-purple-600",
  },
  {
    title: "Electronics",
    count: 82,
    icon: FiMonitor,
    color: "bg-blue-100 text-blue-600",
  },
  {
    title: "Mobiles",
    count: 61,
    icon: FiSmartphone,
    color: "bg-green-100 text-green-600",
  },
  {
    title: "Furniture",
    count: 39,
    icon: FiHome,
    color: "bg-yellow-100 text-yellow-600",
  },
  {
    title: "Sports",
    count: 27,
    icon: FiActivity,
    color: "bg-red-100 text-red-600",
  },
  {
    title: "Others",
    count: 54,
    icon: FiGrid,
    color: "bg-gray-100 text-gray-700",
  },
];

const Categories = () => {
  return (
    <section className="mt-16">

      <div className="flex items-center justify-between mb-8">

        <div>
          <h2 className="text-4xl font-bold text-gray-900">
            Browse Categories
          </h2>

          <p className="text-gray-500 mt-2">
            Explore products across different categories.
          </p>
        </div>

        <button className="text-purple-600 font-semibold hover:text-purple-700">
          View All →
        </button>

      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">

        {categories.map((category) => (
          <CategoryCard
            key={category.title}
            {...category}
          />
        ))}

      </div>

    </section>
  );
};

export default Categories;