import { FiArrowRight } from "react-icons/fi";

const CategoryCard = ({ icon: Icon, title, count, color }) => {
  return (
    <div
      className="
        group
        bg-white
        rounded-[24px]
        border
        border-gray-100
        shadow-sm
        hover:shadow-xl
        hover:-translate-y-2
        transition-all
        duration-300
        p-6
        cursor-pointer
      "
    >
      <div
        className={`
          w-16
          h-16
          rounded-2xl
          ${color}
          flex
          items-center
          justify-center
          mb-6
        `}
      >
        <Icon size={30} />
      </div>

      <h3 className="text-xl font-bold text-gray-900">
        {title}
      </h3>

      <p className="text-gray-500 mt-2">
        {count} Products
      </p>

      <div className="mt-6 flex items-center text-purple-600 font-semibold group-hover:translate-x-1 transition-all">
        Browse
        <FiArrowRight className="ml-2" />
      </div>
    </div>
  );
};

export default CategoryCard;