import { FiArrowRight } from "react-icons/fi";

const UserCard = () => {
  return (
    <div className="bg-white rounded-[28px] shadow-sm border border-gray-100 p-6">

      <div className="flex items-start justify-between">

        <div>

          <p className="text-sm text-gray-500">
            Welcome back,
          </p>

          <h2 className="mt-2 text-3xl font-bold text-gray-900">
            Shubham
          </h2>

          <div className="mt-3 flex items-center gap-2">

            <span className="px-3 py-1 rounded-full bg-purple-100 text-purple-600 text-xs font-semibold">
              Student
            </span>

            <span className="text-sm text-gray-500">
              TY • IT
            </span>

          </div>

        </div>

        <img
          src="https://i.pravatar.cc/150?img=12"
          alt="Profile"
          className="w-16 h-16 rounded-full object-cover border-2 border-purple-200"
        />

      </div>

      <div className="mt-6 pt-4 border-t border-gray-100 flex items-center justify-between">

        <div>

          <p className="text-sm text-gray-500">
            College
          </p>

          <p className="font-semibold text-gray-800">
            MES College
          </p>

        </div>

        <button className="flex items-center gap-2 text-purple-600 font-semibold hover:text-purple-700 transition">

          View Profile

          <FiArrowRight />

        </button>

      </div>

    </div>
  );
};

export default UserCard;