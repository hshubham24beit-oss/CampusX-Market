import HeroBanner from "./HeroBanner";
import UserCard from "./UserCard";
import WhyCampus from "./WhyCampusX";
import RecentChats from "./RecentChats";
import SellCard from "./SellCard";

const Hero = () => {
  return (
    <section className="w-full bg-gray-50 py-6">
      <div className="max-w-[1550px] mx-auto px-6">

        {/* Main Grid */}
        <div className="grid grid-cols-12 gap-6">

          {/* LEFT */}
          <div className="col-span-8">
            <HeroBanner />
          </div>

          {/* RIGHT */}
          <div className="col-span-4 flex flex-col gap-6">

            <UserCard />

            <WhyCampus />

            <RecentChats />

            <SellCard />

          </div>

        </div>

      </div>
    </section>
  );
};

export default Hero;