import { FiPlusCircle } from "react-icons/fi";

const SellCard = () => {
  return (
    <div className="bg-gradient-to-r from-purple-600 to-violet-500 rounded-[28px] text-white p-6 shadow-lg">

      <h2 className="text-2xl font-bold">
        Ready to Sell?
      </h2>

      <p className="mt-3 text-purple-100 leading-7">
        Turn your unused items into cash.
        List your product in less than a minute.
      </p>

      <button className="mt-6 w-full bg-white text-purple-700 font-semibold py-3 rounded-xl flex justify-center items-center gap-2 hover:bg-gray-100 transition">

        <FiPlusCircle />

        Sell Product

      </button>

    </div>
  );
};

export default SellCard;