import { FiMessageCircle } from "react-icons/fi";

const chats = [
  {
    name: "Rahul Sharma",
    message: "Is the laptop still available?",
    time: "2 min",
  },
  {
    name: "Priya Patel",
    message: "Can you reduce the price?",
    time: "10 min",
  },
  {
    name: "Aman Verma",
    message: "Interested in your book.",
    time: "25 min",
  },
];

const RecentChats = () => {
  return (
    <div className="bg-white rounded-[28px] border border-gray-100 shadow-sm p-6">

      <div className="flex justify-between items-center mb-5">

        <h2 className="text-xl font-bold">
          Recent Chats
        </h2>

        <FiMessageCircle className="text-purple-600 text-xl" />

      </div>

      <div className="space-y-4">

        {chats.map((chat, index) => (

          <div
            key={index}
            className="flex items-center gap-3 hover:bg-gray-50 rounded-xl p-2 transition"
          >

            <img
              src={`https://i.pravatar.cc/100?img=${index + 10}`}
              alt=""
              className="w-12 h-12 rounded-full"
            />

            <div className="flex-1">

              <h3 className="font-semibold text-gray-800">
                {chat.name}
              </h3>

              <p className="text-sm text-gray-500 truncate">
                {chat.message}
              </p>

            </div>

            <span className="text-xs text-gray-400">
              {chat.time}
            </span>

          </div>

        ))}

      </div>

    </div>
  );
};

export default RecentChats;