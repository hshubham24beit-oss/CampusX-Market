function Stats(){

const stats=[

{
number:"500+",
title:"Products"
},

{
number:"1200+",
title:"Students"
},

{
number:"350+",
title:"Successful Trades"
},

{
number:"4.9★",
title:"Average Rating"
}

];

return(

<div className="grid grid-cols-4 gap-5 mt-6">

{

stats.map((item,index)=>(

<div
key={index}
className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 text-center"
>

<h2 className="text-4xl font-bold text-purple-600">
{item.number}
</h2>

<p className="mt-2 text-gray-500">
{item.title}
</p>

</div>

))

}

</div>

)

}

export default Stats;