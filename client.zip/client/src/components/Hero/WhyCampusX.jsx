import {
  FiShield,
  FiUsers,
  FiDollarSign,
  FiMessageSquare,
} from "react-icons/fi";

const features = [
  {
    icon: <FiShield className="text-purple-600 text-xl" />,
    title: "Verified Students",
    desc: "Only college students can join.",
  },
  {
    icon: <FiDollarSign className="text-green-600 text-xl" />,
    title: "Best Deals",
    desc: "Save money by buying locally.",
  },
  {
    icon: <FiMessageSquare className="text-blue-600 text-xl" />,
    title: "Easy Chat",
    desc: "Connect directly with sellers.",
  },
  {
    icon: <FiUsers className="text-orange-500 text-xl" />,
    title: "Campus Community",
    desc: "Trade safely within your college.",
  },
];

const WhyCampusX = () => {
  return (
    <div className="bg-white rounded-[28px] border border-gray-100 shadow-sm p-6">

      <h2 className="text-xl font-bold text-gray-900 mb-5">
        Why CampusX?
      </h2>

      <div className="space-y-4">

        {features.map((item, index) => (
          <div
            key={index}
            className="flex gap-4 items-start p-3 rounded-xl hover:bg-gray-50 transition"
          >
            <div className="w-11 h-11 rounded-xl bg-gray-100 flex items-center justify-center">
              {item.icon}
            </div>

            <div>
              <h3 className="font-semibold text-gray-800">
                {item.title}
              </h3>

              <p className="text-sm text-gray-500">
                {item.desc}
              </p>
            </div>
          </div>
        ))}

      </div>

    </div>
  );
};

export default WhyCampusX;