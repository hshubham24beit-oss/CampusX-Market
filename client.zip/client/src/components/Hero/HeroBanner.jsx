import heroImage from "../../assets/hero.png";

const HeroBanner = () => {
  return (
    <div className="w-full h-[470px] rounded-[32px] bg-gradient-to-r from-[#F5F2FF] to-[#EEF2FF] overflow-hidden shadow-sm">

      <div className="grid grid-cols-2 h-full">

        {/* LEFT */}

        <div className="flex flex-col justify-center px-14">

          <span className="inline-flex w-fit items-center px-4 py-2 rounded-full bg-purple-100 text-purple-700 font-medium text-sm">
            🎓 Students Only Marketplace
          </span>

          <h1 className="mt-7 text-[58px] font-extrabold leading-[66px] text-gray-900">

            Buy, Sell,

            <br />

            Connect

            <br />

            with

            <span className="text-purple-600">
              {" "}CampusX
            </span>

          </h1>

          <p className="mt-6 text-gray-600 text-lg leading-8 max-w-xl">

            The exclusive marketplace for students.

            Buy and sell books, laptops,

            mobiles, furniture,

            sports items and much more.

          </p>

          <div className="flex gap-5 mt-10">

            <button className="px-8 py-4 rounded-xl bg-purple-600 text-white font-semibold hover:bg-purple-700 transition">

              Explore Products

            </button>

            <button className="px-8 py-4 rounded-xl bg-white border border-gray-200 font-semibold hover:bg-gray-100 transition">

              Sell Now

            </button>

          </div>

        </div>

        {/* RIGHT */}

        <div className="flex items-center justify-center">

          <img
            src={heroImage}
            alt="CampusX"
            className="w-[520px] object-contain"
          />

        </div>

      </div>

    </div>
  );
};

export default HeroBanner;