import {
  FiSearch,
  FiShoppingCart,
  FiHeart,
  FiMessageCircle,
  FiBell,
  FiChevronDown,
  FiPlusCircle,
} from "react-icons/fi";

const Navbar = () => {
  return (
    <header className="w-full bg-white shadow-sm border-b border-gray-200">

      <div className="w-full h-20 px-8 flex items-center">

        {/* ================= LOGO ================= */}

        <div className="w-[260px] flex items-center gap-3">

          <div className="w-14 h-14 rounded-2xl bg-gradient-to-r from-purple-700 to-violet-500 flex items-center justify-center text-white font-bold text-3xl">
            C
          </div>

          <div>

            <h1 className="text-[36px] leading-none font-bold text-gray-900">
              Campus<span className="text-purple-600">X</span>
            </h1>

            <p className="text-gray-500 text-sm tracking-[5px] uppercase">
              MARKET
            </p>

          </div>

        </div>

        {/* ================= SEARCH ================= */}

        <div className="w-[460px] ml-12">

          <div className="relative">

          <FiSearch
            className="absolute left-[18px] top-1/2 -translate-y-1/2 text-gray-400 text-lg"
          />

          <input
            type="text"
            placeholder="Search books, laptops, mobiles..."
            className="
              w-full
              h-12
              rounded-xl
              border
              border-gray-200
              bg-gray-50
              pl-[50px]
              pr-5
              text-[15px]
              outline-none
              focus:ring-2
              focus:ring-purple-500
            "
          />

          </div>

        </div>

        {/* ================= RIGHT ================= */}

        <div className="flex-1 flex justify-end items-center gap-7">

          {/* Sell Button */}

          <button
            className="
              flex
              items-center
              gap-2
              px-6
              py-3
              rounded-xl
              border
              border-purple-600
              text-purple-600
              font-semibold
              hover:bg-purple-600
              hover:text-white
              transition
            "
          >
            <FiPlusCircle className="text-lg" />
            Sell
          </button>

          {/* Cart */}

          <div className="relative cursor-pointer">

            <FiShoppingCart className="text-2xl text-gray-700 hover:text-purple-600 transition" />

            <span
              className="
                absolute
                -top-2
                -right-2
                w-5
                h-5
                rounded-full
                bg-purple-600
                text-white
                text-[10px]
                flex
                items-center
                justify-center
                font-semibold
              "
            >
              3
            </span>

          </div>

          {/* Wishlist */}

          <div className="relative cursor-pointer">

            <FiHeart className="text-2xl text-gray-700 hover:text-purple-600 transition" />

            <span
              className="
                absolute
                -top-2
                -right-2
                w-5
                h-5
                rounded-full
                bg-purple-600
                text-white
                text-[10px]
                flex
                items-center
                justify-center
                font-semibold
              "
            >
              5
            </span>

          </div>

          {/* Chat */}

          <div className="cursor-pointer">

            <FiMessageCircle className="text-2xl text-gray-700 hover:text-purple-600 transition" />

          </div>

          {/* Notification */}

          <div className="relative cursor-pointer">

            <FiBell className="text-2xl text-gray-700 hover:text-purple-600 transition" />

            <span
              className="
                absolute
                -top-2
                -right-2
                w-5
                h-5
                rounded-full
                bg-purple-600
                text-white
                text-[10px]
                flex
                items-center
                justify-center
                font-semibold
              "
            >
              2
            </span>

          </div>

          {/* Profile */}

          <div className="flex items-center gap-3 cursor-pointer">

            <img
              src="https://i.pravatar.cc/150?img=12"
              alt="profile"
              className="w-12 h-12 rounded-full object-cover"
            />

            <span className="font-semibold text-gray-800 text-lg">
              Shubham
            </span>

            <FiChevronDown className="text-gray-500 text-lg" />

          </div>

        </div>

      </div>

    </header>
  );
};

export default Navbar;