import ProductCard from "./ProductCard";

const products = [
  {
    id: 1,
    title: "MacBook Air M2",
    price: 72000,
    condition: "Like New",
    department: "TY • IT",
  },
  {
    id: 2,
    title: "iPhone 13",
    price: 38000,
    condition: "Good",
    department: "SY • CE",
  },
  {
    id: 3,
    title: "Java Programming",
    price: 350,
    condition: "New",
    department: "FY • MCA",
  },
  {
    id: 4,
    title: "Gaming Chair",
    price: 4500,
    condition: "Used",
    department: "TY • AIDS",
  },
  {
    id: 5,
    title: "Canon DSLR",
    price: 28000,
    condition: "Like New",
    department: "SY • IT",
  },
  {
    id: 6,
    title: "Study Table",
    price: 1800,
    condition: "Good",
    department: "FY • CE",
  },
  {
    id: 7,
    title: "Football Kit",
    price: 900,
    condition: "New",
    department: "TY • EXTC",
  },
  {
    id: 8,
    title: "Wireless Headphones",
    price: 2500,
    condition: "Like New",
    department: "SY • AIDS",
  },
];

const FeaturedProducts = () => {
  return (
    <section className="mt-20">

      {/* Heading */}

      <div className="flex justify-between items-center mb-8">

        <div>

          <h2 className="text-4xl font-bold text-gray-900">
            Featured Products
          </h2>

          <p className="text-gray-500 mt-2">
            Discover the latest products posted by students.
          </p>

        </div>

        <button className="text-purple-600 font-semibold hover:text-purple-700 transition">
          View All →
        </button>

      </div>

      {/* Products */}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-7">

        {products.map((product) => (

          <ProductCard
            key={product.id}
            product={product}
          />

        ))}

      </div>

    </section>
  );
};

export default FeaturedProducts;