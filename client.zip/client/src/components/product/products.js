import book from "../../assets/products/book.jpg";
import laptop from "../../assets/products/laptop.jpg";
import mobile from "../../assets/products/mobile.jpg";
import chair from "../../assets/products/chair.jpg";

const products = [
  {
    id: 1,
    title: "MacBook Air M2",
    price: 72000,
    condition: "Like New",
    department: "TY • IT",
    image: laptop,
  },
  {
    id: 2,
    title: "iPhone 13",
    price: 38000,
    condition: "Good",
    department: "SY • CE",
    image: mobile,
  },
  {
    id: 3,
    title: "Java Programming",
    price: 350,
    condition: "New",
    department: "FY • MCA",
    image: book,
  },
  {
    id: 4,
    title: "Study Chair",
    price: 1500,
    condition: "Used",
    department: "TY • AIDS",
    image: chair,
  },
];

export default products;