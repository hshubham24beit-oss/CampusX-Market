import {
  FiHeart,
  FiMapPin,
  FiEye,
} from "react-icons/fi";

const ProductCard = ({ product }) => {
  return (
    <div
      className="
      group
      bg-white
      rounded-[24px]
      overflow-hidden
      border
      border-gray-100
      shadow-sm
      hover:shadow-xl
      transition-all
      duration-300
      hover:-translate-y-2
      "
    >
      {/* Product Image */}

      <div className="relative h-56 bg-gradient-to-br from-purple-50 to-indigo-100 flex items-center justify-center">

        <button
          className="
          absolute
          top-4
          right-4
          w-10
          h-10
          rounded-full
          bg-white
          shadow
          flex
          items-center
          justify-center
          hover:bg-purple-600
          hover:text-white
          transition
          "
        >
          <FiHeart />
        </button>

        <span
          className="
          absolute
          top-4
          left-4
          bg-purple-600
          text-white
          px-3
          py-1
          rounded-full
          text-xs
          font-semibold
          "
        >
          {product.condition}
        </span>

        <div className="text-center">

          <div className="text-7xl">
            📦
          </div>

          <p className="mt-3 text-gray-500 text-sm">
            Product Image
          </p>

        </div>

      </div>

      {/* Product Details */}

      <div className="p-6">

        <h3
          className="
          text-xl
          font-bold
          text-gray-900
          line-clamp-1
          "
        >
          {product.title}
        </h3>

        <p
          className="
          mt-3
          text-3xl
          font-extrabold
          text-purple-600
          "
        >
          ₹{product.price.toLocaleString()}
        </p>

        <div
          className="
          flex
          items-center
          gap-2
          mt-4
          text-gray-500
          "
        >
          <FiMapPin />

          <span>
            {product.department}
          </span>

        </div>

        <button
          className="
          w-full
          mt-6
          py-3
          rounded-xl
          bg-purple-600
          hover:bg-purple-700
          text-white
          font-semibold
          flex
          items-center
          justify-center
          gap-2
          transition
          "
        >
          <FiEye />

          View Details

        </button>

      </div>

    </div>
  );
};

export default ProductCard;